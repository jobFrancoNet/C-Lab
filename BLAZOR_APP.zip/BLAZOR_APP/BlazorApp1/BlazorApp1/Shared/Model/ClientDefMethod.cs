﻿namespace BlazorApp1.Shared.Model
{
    //public class ClientDefMethod
    //{
    //}

    public partial class Clienti
    {

        public void StampaMessaggio()
        {

        }

        public void StampaTitle()
        {

        }
        partial void StampaMessaggio(string TitleMessage)
        {
            throw new NotImplementedException();
        }
    }
}
