﻿namespace BlazorApp1.Shared.Model
{
    public partial class Clienti
    {
        public int Id { get; set; }

        public string Cognome { get; set; }

        public string Nome { get; set; }


        partial void StampaMessaggio(string TitleMessage);
    }
}
